import Cocoa

var beatles = ["John", "Paul", "George", "Ringo"]

var numbers = [4, 8, 15, 16, 23, 42]

var temperatures = [25.3, 28.2, 26.4]

print(beatles[0])

print(numbers[1])

print(temperatures[2])

beatles.append("Adrian")
beatles.append("Allen")

var scores = Array<Int>()
scores.append(100)
scores.append(80)
scores.append(85)
print(scores[1])

var albums =  [String]()
albums.append("Folklore")
albums.append("Fearless")
albums.append("Red")
albums.append("Midnight")

print(albums.count)

var characters = ["Lana", "Pam", "Ray", "Sterling"]
print(characters.count)

characters.remove(at: 2)
print(characters.count)

characters.removeAll()
print(characters.count)

let bondMovies = ["Casino Royale", "Spectre", "No Time to Die"]
print(bondMovies.contains("Frozen"))

print(bondMovies.sorted())

let cities = ["London", "Tokyo", "Rome", "Pflugerville"]
print(cities.sorted())

let presidents = ["Bush", "Obama", "Trump", "Biden"]
let reversedPresidents = presidents.reversed()
print(reversedPresidents)

var employee = ["Taylor Swift", "Singer", "Nashville"]
print("Name: \(employee[0])")

let employee2 = [
    "name": "Taylor Swift",
    "job": "Singer",
    "location": "Nashville",
    "password": "Somethiong",
    ]
print(employee2["name", default: "Unknown"])
print(employee2["job", default: "Unknown"])
print(employee2["location", default: "Unknown"])
print(employee2["password", default: "Unknown"])

let hasGraduated = [
    "Eric": false,
    "Maeve": true,
    "Otis": false
]

let olympics = [
    2012: "London",
    2016: "Rio",
    2021: "Tokyo"
    ]

print(olympics[2012, default: "Unkown"])

var heights = [String: Int]()
heights["Yao Ming"] = 229
heights["Shaq O'Neal"] = 216
heights ["LeBrron James"] = 206

var archEnemeies = [String : String]()
archEnemeies["Batman"] = "The Joker"
archEnemeies

let actors = Set ([
    "Denmzel",
    "Tom Cruise",
    "Nick Cage",
    "Sam Jackson"
    ])
print(actors)

var selected = "Monday"
selected = "Tuesday"
selected = "Jan"
selected = "Friday "

enum Weekday {
    case Monday, Tuesday, Wednesday, Thursday, Friday
}

var day = Weekday.Monday
day = .Tuesday
day = .Friday

